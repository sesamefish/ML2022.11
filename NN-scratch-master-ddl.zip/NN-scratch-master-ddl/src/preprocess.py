import os,sys
import json
import csv
import random

from src.size_analysis import normalize_height,normalize_weight,normalize_bust_size,normalize_fit

fields=["height","weight","bust_size","body_type","rented_for","usually_wear","size","fit"]
input_dict=dict()

def create_input_dict(tag:str)->None:
  if fields.count(tag)==0:
    raise ValueError("No such tag in fields")

  with open("../ML_dataset/checkout/checkout_"+tag+".json",mode="r") as f_in:
    new_dict=dict(json.load(f_in))
    f_in.close()  

  input_dict.update({tag:new_dict})

def distribute_list(tag:str,text:str)->list  or None:
  if fields.count(tag)==0:
    raise ValueError("No such tag in fields")  

  return input_dict.get(text)  

def preprocess_2(fin_path:str="../../ML_dataset/train_data_all.json",
  fout_path:str="../data/dataset.csv",
  dataset_size:int=3000)->None:
  input_fields=["height","weight","size"]
  output_fields=["fit"]

  with open("./data/distribute_size_height.json",mode="r") as f_in:
    height_dict=json.load(f_in)
    f_in.close()

  with open("./data/distribute_size_weight.json",mode="r") as f_in:
    weight_dict=json.load(f_in)
    f_in.close()

  with open("./data/distribute_size_bust_size.json",mode="r") as f_in:
    bust_size_dict=json.load(f_in)
    f_in.close()

  def normalize_data_2(raw_data:dict)->list or None:
    new_data=list()
    new_data.append(normalize_height(raw_data["height"]))
    size_height=height_dict[raw_data["size"]]
    if len(size_height)==3:
      new_data.append(size_height[0]) 
    #new_data.extend(height_dict[raw_data["size"]])
    new_data.append(normalize_weight(raw_data["weight"]))
    size_weight=weight_dict[raw_data["size"]]
    if len(size_weight)==3:
      new_data.append(size_weight[0])
    #new_data.extend(weight_dict[raw_data["size"]])
    new_data.append(normalize_bust_size(raw_data["bust_size"]))
    size_bust=bust_size_dict[raw_data["size"]]
    if len(size_bust)==3:
      new_data.append(size_bust[0])
    new_data.append(normalize_fit(raw_data["fit"]))
    if len(new_data)<7 or new_data.count(None)>0:
      return None
    else:
      return new_data

  for tag in input_fields:
    create_input_dict(tag)

  with open(fin_path,encoding="utf-8",mode="r") as f_in:
    raw_data_list=json.load(f_in)
    f_in.close()

  data_list=list() #input data
  data_labeled_list={1:[],2:[],3:[]} #for each fit tag
  for raw_data in raw_data_list:
    new_data=normalize_data_2(raw_data)
    if new_data==None:
      continue    
    fit_tag=new_data[-1]
    for i in range(0,5,2):
      new_data[i]=round(new_data[i]-new_data[i+1],2) 

    new_data.pop(5)
    new_data.pop(3)
    new_data.pop(1)
    data_labeled_list[fit_tag].append(new_data)

  size_each_tag=round(dataset_size/3)
  for fit_tag in range(1,4):
    data_labeled_list[fit_tag]=random.sample(data_labeled_list[fit_tag],min(size_each_tag,len(data_labeled_list[fit_tag])))  
    data_list+=data_labeled_list[fit_tag]
  random.shuffle(data_list)

  #csv_fields=["height","h1","h2","h3","weight","w1","w2","w3","fit"]
  csv_fields=["height","weight","bust_size","fit"]

  with open(fout_path,encoding="utf-8",mode="w") as f_out:
    csvWriter=csv.writer(f_out)
    csvWriter.writerow(csv_fields)
    csvWriter.writerows(data_list)
    f_out.close()

  print("train dataset size:",len(data_list))

def preprocess(fin_path:str="C:/Users/22698/Desktop/NN-scratch-master-ddl/data/dataset.csv",
  fout_path:str="../data/dataset.csv",
  dataset_size:int=3000)->None:
  #normalization parameters
  size_dict={"XS":0,"S":1,"M":2,"L":3,"XL":4} 
  body_type_dict={"APPLE":0,"ATHLETIC":1,"PETITE":2,"PEAR":4,"HOURGLASS":8,
    "STRAIGHT & NARROW":16,"FULL BUST":32}
  fit_dict={"Small":1,"True to Size":2,"Large":3}
  rent_for_dict={  "everyday": 0,  "work": 1,  "party": 2,  "other": 4,  "vacation": 8,
    "date": 16,  "wedding": 32,  "formal affair": 64}
  item_dict_2={}

  with open("C:/Users/22698/Desktop/NN-scratch-master-ddl/data/item_name_dict.json",mode="r") as f_in:
    item_dict=dict(json.load(f_in))
    f_in.close()

  with open("C:/Users/22698/Desktop/NN-scratch-master-ddl/data/distribute_size_bust_size.json",mode="r") as f_in:
    bust_size_dict=json.load(f_in)
    f_in.close()
  with open("C:/Users/22698/Desktop/NN-scratch-master-ddl/data/distribute_size_height.json",mode="r") as f_in:
    height_dict=json.load(f_in)
    f_in.close()
  with open("C:/Users/22698/Desktop/NN-scratch-master-ddl/data/distribute_size_weight.json",mode="r") as f_in:
    weight_dict=json.load(f_in)
    f_in.close()
  """with open("./ML_dataset/checkout/checkout_size.json",mode="r") as f_in:
    size_dict=dict(json.load(f_in))
    f_in.close()"""


  def normalize_body_type(text:str)->int or None:
    return body_type_dict.get(text)

  def normalize_rented_for(text:str)->int or None:
    purpose=str.lower(text)
    return rent_for_dict.get(purpose)

  def normalize_price(text:str)->int or None:
    return round(int(text[1:])/100)

  def normalize_usually_wear(text:str)->int or None:
    return int(text)

  def normalize_item_name(text:str)->list:
    fit_list=item_dict[text] 
    fit_list.pop(-1)
    if len(fit_list)!=3:
      fit_list.append(0)
    return fit_list

  def normalize_item_name_2(text:str)->int:
    if item_dict_2.get(text)==None:
      item_dict_2.update({text:len(item_dict_2)})
    return item_dict_2[text]

  """def normalize_size(text:str)->int:
    #size=size_dict.get(text)
    new_size=size_dict.get(text)
    if new_size==None:
      size_dict.update({text:len(size_dict)})

    return size_dict[text]"""

  def normalize_fit(text:str)->int or None:
    return fit_dict.get(text)

  def normalize_data(data:dict)->list or None:
    '''
    raw_input_data=[data["height"],data["weight"],
      data["body_type"], data["size"],data["rented_for"],data["price"],
      data["item_name"],data["usually_wear"],data["fit"]]'''
    raw_input_data=[data["height"],data["weight"], data["size"],
      data["bust_size"],data["item_name"],data["fit"]]
    if data["size"]==None or data["size"]=='' or data["fit"]==None or data["fit"]=='':
      return None

    new_data=[
      normalize_height(data["height"]),
      normalize_weight(data["weight"]),
      normalize_bust_size(data["bust_size"]),
      #normalize_body_type(data["body_type"]),
      
      #normalize_rented_for(data["rented_for"]),
      #normalize_price(data["price"]),
      #normalize_usually_wear(data["usually_wear"]),
    ]

    if len(height_dict[raw_data["size"]]+\
      weight_dict[raw_data["size"]]+\
      bust_size_dict[raw_data["size"]])<9:
      return None
    if new_data[0]==None:
      new_data[0]=0
    else:
      new_data[0]=round(new_data[0]-float(height_dict[raw_data["size"]][2]),2)
    if new_data[1]==None:
      new_data[1]=0
    else:
      new_data[1]=new_data[1]-float(weight_dict[raw_data["size"]][2])
    if new_data[2]==None:
      new_data[2]=0
    else:
      new_data[2]=new_data[2]-float(bust_size_dict[raw_data["size"]][2])
    #new_data.append(normalize_item_name_2(data["item_name"]))
    #new_data.append(normalize_size(data["size"]))

    ratio=[0.1,0.01,1]
    #new_data=[ i**2 for i in new_data]
    new_data=[new_data[i]*ratio[i] for i in range(0,3)]
    new_data.extend(normalize_item_name(data["item_name"]))
    new_data.append(normalize_fit(data["fit"]))
    return new_data

  with open(fin_path,encoding="utf-8",mode="r") as f_in:
    raw_data_list=json.load(f_in)
    f_in.close()

  data_list=list() #input data
  data_labeled_list={1:[],2:[],3:[]} #for each fit tag
  for raw_data in raw_data_list:
    new_data=normalize_data(raw_data)
    if new_data==None:
      continue    
    #data_list.append(new_data)  
    fit_tag=new_data[-1]
    data_labeled_list[fit_tag].append(new_data)

  size_each_tag=round(dataset_size/3)
  for fit_tag in range(1,4):
    data_labeled_list[fit_tag]=random.sample(data_labeled_list[fit_tag],min(size_each_tag,len(data_labeled_list[fit_tag])))  
    data_list+=data_labeled_list[fit_tag]
  random.shuffle(data_list)

  #dataset_size=min(dataset_size,len(data_list))
  #data_list=random.sample(data_list,dataset_size)  "rented_for","item_name","size",
  fields=["height_diff","weight_diff","bust_size_diff","i1","i2","i3","fit"]
  #fields=["name1","name2","name3","size","fit"]
  #fields=["height","weight","bust_size","size","fit"]
  with open(fout_path,encoding="utf-8",mode="w") as f_out:
    csvWriter=csv.writer(f_out)
    csvWriter.writerow(fields)
    csvWriter.writerows(data_list)
    f_out.close()

  print("train dataset size:",len(data_list))


def main()->None:
  os.chdir(sys.path[0])
  preprocess()
  print("preprocess completed.\n")

if __name__ == "__main__":
  main()

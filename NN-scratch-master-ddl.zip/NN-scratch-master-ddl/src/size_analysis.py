import os,sys
import json
import re
from collections import Counter

def normalize_height(text:str)->float or None:
  pattern=re.compile(r"[0-9]")
  strs=pattern.findall(text)
  if len(strs)<2:
    return None
  foot=strs[0]
  inch=strs[1]
  if str.isnumeric(foot) and str.isnumeric(inch):
    height=round(int(foot)*30.48+int(inch)*2.54,2)
    return height
  else:
    return None

def normalize_weight(text:str)->int or None:
  if len(text)!=6 :
    return None
  elif text.endswith("LBS")==False:
    return None
  elif str.isnumeric(text[0:3]):
    return int(text[0:3])
  elif str.isnumeric(text[0:2]):
    return int(text[0:2])

def normalize_bust_size(text:str)->int or None:
  num_list = re.findall(r'\d+', text)
  sum = 0
  if len(num_list) != 0:
    num_list[0] = int(num_list[0])
    sum = num_list[0]
  if 'AA' in text:
    sum = sum + 1
  elif 'A' in text:
    sum = sum + 2
  elif 'B' in text:
    sum = sum + 3
  elif 'C' in text:
    sum = sum + 4
  elif 'E' in text:
    sum = sum + 7
  elif 'DD' in text:
    sum = sum + 6
  elif 'D' in text:
    sum = sum + 5
  elif 'F' in text:
    sum = sum + 8
  elif 'G' in text:
    sum = sum + 9
  elif 'H' in text:
    sum = sum + 10
  elif 'I' in text:
    sum = sum + 11
  elif 'J' in text:
    sum = sum + 12
  if len(text)<2:
    return None
  if str.isnumeric(text[0:2]):
    return int(text[0:2])

def normalize_fit(text:str)->int or None:
  fit_dict={"small":1,"true to size":2,"large":3}
  return fit_dict.get(str.lower(text))

def size_analysis(target_item:str="bust_size",fin_path:str="../../ML_dataset/train_data_all.json")->None:
  fit_dict={"Small":0,"True to Size":1,"Large":2,"":3}
  with open(fin_path,encoding="utf-8",mode="r") as f_in:
    dataset=json.load(f_in) #a list of dicts
    f_in.close()

  size_dict=dict()
  fit_dataset=list()
  for raw_data in dataset:
    if str.lower(raw_data["fit"])=="true to size" and \
        raw_data[target_item]!='' and \
        raw_data[target_item]!=None:
      fit_dataset.append(raw_data)

  for raw_data in dataset:
    new_size=raw_data["size"]
    if new_size not in size_dict.keys():
      size_dict.update({new_size:[]})

  new_list=list()
  for _size in size_dict.keys():
    new_list.clear()
    for raw_data in fit_dataset:      
      if raw_data["size"]!=_size:
        continue
      new_item=raw_data[target_item]
      if new_item=="36DD":
        pass
      new_item=normalize_bust_size(new_item)
      if new_item!=None:
        new_list.append(new_item)

    if len(new_list)==0:
      continue

    new_list.sort()
    average=round(sum(new_list)/len(new_list),2) #averge
    median=new_list[round(len(new_list)/2)] #median
    common,_=Counter(new_list).most_common(1)[0]#most common
    size_dict[_size]=[average,median,common]

  #size_dict=dict(sorted(size_dict.items(),key=lambda x:x[1],reverse=True))

  with open("../data/distribute_size_"+target_item+".json",mode="w",encoding="utf-8") as f_out:
    json.dump(size_dict,f_out,indent=2)
    f_out.close()


def main():
  os.chdir(sys.path[0])
  size_analysis()

if __name__ == "__main__":
  main()


import json
import os,sys
import re

os.chdir(sys.path[0])
fit_review_vocab=["true to size","perfect","lovly","cute",\
  "loved","love","comfortable","cute"]
small_review_vocab=["small","short","tight"]
large_review_vocab=["large","big"]

with open("../../ML_dataset/train_data_all.json",encoding="utf-8",mode="r") as f_in:
  dataset=json.load(f_in) #a list of dicts
  f_in.close()

for raw_data in dataset:
  fit=raw_data["fit"]
  if fit==None or fit=='':
    review=str.lower(raw_data["review_summary"]+" "+raw_data["review"]) #predict from review
    rating=raw_data["rating"] #predict from rating
    if rating=='5':
      for vocab in fit_review_vocab:
        if review.find(vocab)!= -1:
          raw_data["fit"]="True to Size"
          break
    for vocab in small_review_vocab:
      if review.find(vocab)!= -1:
        raw_data["fit"]="Small"
        break
    for vocab in large_review_vocab:
      if review.find(vocab)!= -1:
        raw_data["fit"]="Large"
        break

with open("../../ML_dataset/train_data_all_pred_1.json",encoding="utf-8",mode="w") as f_out:
  json.dump(dataset,f_out,indent=2)
  f_in.close()
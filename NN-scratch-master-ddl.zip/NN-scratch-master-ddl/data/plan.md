# Neural Network parameters

Learing rate $\eta$ would be iteriated dynamically, following the fomula with a prior paremeter:
$$
\eta= \frac{\eta _0}{1+\kappa \times (n/N)}
$$
where $\eta _0$is the initial learning rate, $n$ is the current epoch and $N$ is the total epoches of training.

The weights are set randomly for default, but the weights between input layer and first hidden layer are initialized with a given list of prior weight $\{\bar w_{j}\}_{j=0}^{n}$. 
$$
w_{ij}=U(0,1)\times \bar w_{j}
$$
where $w_{ij}$ is the weight between $i-th$ node in first hidden layer and $j-th$ input node.

